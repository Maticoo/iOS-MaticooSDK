//
//  MATWebviewBridge.h
//  MaticooSDK
//
//  Created by root on 2023/4/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@protocol MATWebviewBridgeDelegate;

@interface MATWebviewBridge : NSObject
@property (nonatomic, weak) id<MATWebviewBridgeDelegate> delegate;
- (BOOL)parseRequestStr:(NSString*)requestStr;
@end


@protocol MATWebviewBridgeDelegate <NSObject>
@required
- (void)mraidBridge:(MATWebviewBridge*)bridge windowOnload:(BOOL)finish;
- (void)mraidBridgeCloseAd:(MATWebviewBridge*)bridge;
- (void)mraidBridgeJSLoadSuccess:(MATWebviewBridge*)bridge;
- (void)mraidBridgeJSLoadFailed:(MATWebviewBridge*)bridge;
- (void)mraidBridgeVideoImp:(MATWebviewBridge*)bridge;
- (void)mraidBridgeVideoClick:(MATWebviewBridge*)bridge position:(NSString*)position;
- (void)mraidBridgeVideoCompleted:(MATWebviewBridge*)bridge;
- (void)mraidBridgeAdReward:(MATWebviewBridge*)bridge;
- (void)mraidBridgeVideo:(MATWebviewBridge*)bridge isMuted:(BOOL)isMuted;
@end

static NSString* MATWebviewBridgeCommandWindowOnload = @"onload";
static NSString* MATWebviewBridgeCommandConsole = @"console://localhost?";
NS_ASSUME_NONNULL_END
