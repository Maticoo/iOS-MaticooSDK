//
//  Applins.h
//  ApplinsSDK
//
//  Created by Mirinda on 16/7/27.
//  Copyright © 2016年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MaticooSDK/Maticoo.h>
#import <MaticooSDK/ALSADExternalDelegate.h>
#import <MaticooSDK/ALSElementModel.h>
#import <MaticooSDK/ALSNativeAd.h>
#import <MaticooSDK/ALSNativeModelDelegate.h>
#import <MaticooSDK/ALSRewardVideoDelegate.h>
#import <MaticooSDK/ALSNativeVideoModel.h>
#import <MaticooSDK/ALSNativeVideoDelegate.h>
#import <MaticooSDK/ALSVideoViewController.h>
#import <MaticooSDK/ALSMediaView.h>
#import <MaticooSDK/ALSADMRAIDVIew.h>
#import <MaticooSDK/ALSSplashAdDelegate.h>

//! Project version number for ApplinsSDK.
FOUNDATION_EXPORT double MATICOOSDK_VERSIONNumber;
//! Project version string for ApplinsSDK.
FOUNDATION_EXPORT const unsigned char MATICOOSDK_VERSIONString[];

// In this header, you should import all the public headers of your framework using statements like #import <ApplinsSDK/PublicHeader.h>
