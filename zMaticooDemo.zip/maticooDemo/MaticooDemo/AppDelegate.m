//
//  AppDelegate.m
//  MaticooDemo
//
//  Created by root on 2023/4/12.
//

#import "AppDelegate.h"
#import <MaticooSDK/MaticooAds.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [[MaticooAds shareSDK] initSDK:@"fd496c5180b67b7dbb42605e3232d4604090ed8ef8fcda8ff7cbde4d131ba262" onSuccess:^() {
            NSLog(@"Init Success");
        } onError:^(NSError* error) {
            NSLog(@"Init Failed %@", error.description);
        }];
    
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
