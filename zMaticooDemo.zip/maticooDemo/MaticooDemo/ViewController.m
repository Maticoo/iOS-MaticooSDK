//
//  ViewController.m
//  MaticooDemo
//
//  Created by root on 2023/4/12.
//

#import "ViewController.h"
#import <MaticooSDK/MATBannerAd.h>
#import <MaticooSDK/MATNativeAd.h>
#import <MaticooSDK/MATInterstitialAd.h>
#import <MaticooSDK/MATRewardedVideoAd.h>
#import <MaticooSDK/MATInteractAd.h>
#import <MaticooSDK/MATInteractEntranceView.h>
#import <MaticooSDK/MATSplashAd.h>

#define dispatch_main_MATASYNC_safe(block)\
        if ([NSThread isMainThread]) {\
        block();\
        } else {\
        dispatch_async(dispatch_get_main_queue(), block);\
        }

@interface ViewController () <MATBannerAdDelegate, MATNativeAdDelegate, MATInterstitialAdDelegate, MATRewardedVideoAdDelegate, MATInteractAdDelegate, MATSplashAdDelegate>
@property (nonatomic, strong) MATBannerAd *banner;
@property (nonatomic, strong) MATInterstitialAd *interstitial;
@property (nonatomic, strong) MATInterstitialAd *interstitialVideo;
@property (nonatomic, strong) MATNativeAd *native;
@property (nonatomic, strong) MATRewardedVideoAd *rewardedVideo;
@property (nonatomic, strong) MATInteractAd *interact;
@property (nonatomic, strong) MATSplashAd *splash;
@property (nonatomic, strong) MATSplashAd *splashVideo;
@property (nonatomic, strong) UILabel* notification;
@property (weak, nonatomic) IBOutlet UIView *adView;
@property (weak, nonatomic) IBOutlet UIButton *bannerBtn;
@property (weak, nonatomic) IBOutlet UIButton *nativeBtn;
@property (weak, nonatomic) IBOutlet UIButton *nativeVideoBtn;
@property (weak, nonatomic) IBOutlet UIButton *interstitialBtn;
@property (weak, nonatomic) IBOutlet UIButton *interstitialVideoBtn;
@property (weak, nonatomic) IBOutlet UIButton *rewardedVideoBtn;
@property (weak, nonatomic) IBOutlet UIButton *interactBtn;
@property (weak, nonatomic) IBOutlet UIButton *ShowInterstitial;
@property (weak, nonatomic) IBOutlet UIButton *ShowInterstitialVideo;
@property (weak, nonatomic) IBOutlet UIButton *ShowRewardedVideo;
@property (weak, nonatomic) IBOutlet UIButton *splashBtn;
@property (weak, nonatomic) IBOutlet UIButton *showSplashBtn;
@property (weak, nonatomic) IBOutlet UIButton *splashVideoBtn;
@property (weak, nonatomic) IBOutlet UIButton *showSplashVideoBtn;
@property (nonatomic, strong) UIView *nativeAdView;
@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, strong) UIButton *ctaBtn;
@property (nonatomic, strong) MATNativeAdElements *natvieModel;
@property (nonatomic, strong) UIView *closingAdView;
@property (nonatomic, strong) UIView *closedAdView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.notification = [[UILabel alloc]initWithFrame:CGRectMake(self.adView.frame.size.width/2, 0, self.adView.frame.size.width, 200)];
    self.notification.center =  CGPointMake(self.adView.frame.size.width/2, self.notification.center.y);
    self.notification.numberOfLines = 10;
    self.notification.textColor = [UIColor orangeColor];
    self.notification.textAlignment = NSTextAlignmentCenter;
    [self.bannerBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.nativeBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.nativeVideoBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.interstitialBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.interstitialVideoBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.rewardedVideoBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.interactBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.ShowInterstitial addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.ShowInterstitialVideo addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.ShowRewardedVideo addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.splashBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.showSplashBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.splashVideoBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.showSplashVideoBtn addTarget:self action:@selector(clickEvent:) forControlEvents:UIControlEventTouchUpInside];
    self.ShowInterstitial.enabled = NO;
    self.ShowInterstitialVideo.enabled = NO;
    self.ShowRewardedVideo.enabled = NO;
    self.showSplashBtn.enabled = NO;
    self.showSplashVideoBtn.enabled = NO;
    
    //压力测试接口
//    for (int i =0; i < 40; i++) {
//        dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//            MATInterstitialAd *ad = [[MATInterstitialAd alloc] initWithPlacementID:@"1003184754"];
//            ad.delegate = self;
//            [ad loadAd];
//        });
//        dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//            MATInterstitialAd *ad = [[MATInterstitialAd alloc] initWithPlacementID:@"1003184804"];
//            ad.delegate = self;
//            [ad loadAd];
//        });
//        dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//            MATInterstitialAd *ad = [[MATRewardedVideoAd alloc] initWithPlacementID:@"1003184689"];
//            ad.delegate = self;
//            [ad loadAd];
//        });
//        dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//            MATInterstitialAd *ad = [[MATRewardedVideoAd alloc] initWithPlacementID:[[NSString alloc] initWithFormat:@"%d", i]];
//            ad.delegate = self;
//            [ad loadAd];
//        });
//    }
}

//banner
- (void)clickEvent:(UIButton*) sender{
    for (UIView *view in [self.adView subviews]) {
            [view removeFromSuperview];
    }
    
    if ([sender.titleLabel.text isEqual: @"Load Banner"]){
        self.banner = [[MATBannerAd alloc] initWithPlacementID:@"1003200873"];
        self.banner.delegate = self;
        [self.banner loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Load Native"]){
        self.native = [[MATNativeAd alloc] initWithPlacementID:@"1003201105"]; //1003184838  //1003184818
        self.native.delegate = self;
        [self.native setAdTemplateStyle];
        [self.native setRequiredAdElements:AD_TITLE, AD_ICON, AD_CTATEXT];
        [self.native setAdSize:CGSizeMake(300, 250)];
        [self.native setVideoIsMute:YES];
        [self.native loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Load Native Video"]){
        self.native = [[MATNativeAd alloc] initWithPlacementID:@"1003201139"]; //1003184838  //1003184818
        self.native.delegate = self;
        [self.native setAdTemplateStyle];
        [self.native loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Load Interstitial"]){
        self.ShowInterstitial.enabled = NO;
        self.interstitial = [[MATInterstitialAd alloc] initWithPlacementID:@"1003200946"];
        self.interstitial.delegate = self;
        [self.interstitial loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Load Interstitial Video"]){
        self.ShowInterstitialVideo.enabled = NO;
        self.interstitialVideo = [[MATInterstitialAd alloc] initWithPlacementID:@"1003201013"];
        self.interstitialVideo.delegate = self;
        [self.interstitialVideo loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Load Rewarded Video"]){
        self.rewardedVideo = [[MATRewardedVideoAd alloc] initWithPlacementID:@"1003200911"];
        self.rewardedVideo.delegate = self;
        [self.rewardedVideo loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Load Interact"]){
        self.interact = [[MATInteractAd alloc]initWithPlacementID:@"1003200915"];
        self.interact.delegate = self;
        [self.interact loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Show Interstitial"]){
        [self.interstitial showAdFromRootViewController];
        self.ShowInterstitial.enabled = NO;
    }else if ([sender.titleLabel.text isEqual: @"Show Interstitial Video"]){
        [self.interstitialVideo showAdFromRootViewController];
        self.ShowInterstitialVideo.enabled = NO;
    }else if ([sender.titleLabel.text isEqual: @"Show Rewarded Video"]){
        [self.rewardedVideo showAdFromRootViewController];
        self.ShowRewardedVideo.enabled = NO;
    }else if ([sender.titleLabel.text isEqual: @"Load Splash"]){
        self.showSplashBtn.enabled = NO;
        self.splash = [[MATSplashAd alloc] initWithPlacementID:@"1003201174"];
        self.splash.delegate = self;
        [self.splash loadAd];
        self.showSplashBtn.enabled = NO;
    }else if ([sender.titleLabel.text isEqual: @"Show Splash"]){
        [self.splash showAdFromRootViewController];
        self.showSplashBtn.enabled = NO;
    }else if ([sender.titleLabel.text isEqual: @"Load Splash Video"]){
        self.showSplashVideoBtn.enabled = NO;
        self.splashVideo = [[MATSplashAd alloc] initWithPlacementID:@"1003201272"];
        self.splashVideo.delegate = self;
        [self.splashVideo loadAd];
    }else if ([sender.titleLabel.text isEqual: @"Show Splash Video"]){
        [self.splashVideo showAdFromRootViewController];
        self.showSplashVideoBtn.enabled = NO;
    }
}

- (void)bannerAdDidLoad:(MATBannerAd *)nativeBannerAd{
    NSLog(@"bannerAd DidLoad success.");
    for (UIView *view in [self.adView subviews]) {
            [view removeFromSuperview];
    }
    nativeBannerAd.frame = CGRectMake(0, 0, 320, 50);
    [self.adView addSubview:nativeBannerAd];
    return;
}

- (void)bannerAd:(nonnull MATBannerAd *)nativeBannerAd didFailWithError:(nonnull NSError *)error {
    NSLog(@"bannerAd didFailWithError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Load banner ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
    
}

- (void)bannerAdDidClick:(nonnull MATBannerAd *)banner {
    NSLog(@"bannerAdDidClick");
}

- (void)bannerAdDidImpression:(nonnull MATBannerAd *)banner {
    NSLog(@"bannerAdDidImpression");
}

//intersitital delegate
- (void)interstitialAdDidLoad:(MATInterstitialAd *)interstitialAd{
    NSLog(@"interstitialAdDidLoad");
    if (interstitialAd.isReady){
        if(!interstitialAd.isVideo) {
            self.ShowInterstitial.enabled = YES;
            self.notification.text = @"Load interstitial success.";
        }else {
            self.ShowInterstitialVideo.enabled = YES;
            self.notification.text = @"Load interstitial video success.";
        }
        
        [self.adView addSubview:self.notification];
    }
    return;
}

- (void)interstitialAd:(MATInterstitialAd *)interstitialAd didFailWithError:(NSError *)error{
    NSLog(@"interstitialAd didFailWithError, %@", error.description);
    if(interstitialAd.isVideo) {
        dispatch_main_MATASYNC_safe((^{
            self.notification.text = [NSString stringWithFormat:@"Load interstitial ad failed.\n\n Reason: %@", error.description];
            [self.adView addSubview:self.notification];
        }))
    }else {
        dispatch_main_MATASYNC_safe((^{
            self.notification.text = [NSString stringWithFormat:@"Load interstitial viode ad failed.\n\n Reason: %@", error.description];
            [self.adView addSubview:self.notification];
        }))
    }

}

- (void)interstitialAd:(MATInterstitialAd *)interstitialAd displayFailWithError:(NSError *)error{
    NSLog(@"interstitialAd displayFailWithError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Display interstitial ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
    
}

- (void)interstitialAdWillLogImpression:(MATInterstitialAd *)interstitialAd{
    NSLog(@"interstitialAdWillLogImpression");
}

- (void)interstitialAdDidClick:(MATInterstitialAd *)interstitialAd{
    NSLog(@"interstitialAdDidClick");
}

- (void)interstitialAdWillClose:(MATInterstitialAd *)interstitialAd{
    NSLog(@"interstitialAdWillClose");
}

- (void)interstitialAdDidClose:(MATInterstitialAd *)interstitialAd{
    NSLog(@"interstitialAdDidClose");
}

//rewarded video delegate
- (void)rewardedVideoAdDidLoad:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdDidLoad");
    if (rewardedVideoAd.isReady){
        self.ShowRewardedVideo.enabled = YES;
        //    [self.rewardedVideoAd showAdFromViewController:self];
        self.notification.text = @"Load rewarded video success.";
        [self.adView addSubview:self.notification];
    }
}

- (void)rewardedVideoAd:(MATRewardedVideoAd *)rewardedVideoAd didFailWithError:(NSError *)error{
    NSLog(@"rewardedVideoAd didFailWithError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Load rewarded video ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
}

- (void)rewardedVideoAd:(MATRewardedVideoAd *)rewardedVideoAd displayFailWithError:(NSError *)error{
    NSLog(@"rewardedVideoAd displayFailWithError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Display rewarded video ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
}

- (void)rewardedVideoAdStarted:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdStarted");
}

- (void)rewardedVideoAdCompleted:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdCompleted");
}

- (void)rewardedVideoAdWillLogImpression:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdWillLogImpression");
}

- (void)rewardedVideoAdDidClick:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdDidClick");
}

- (void)rewardedVideoAdWillClose:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdWillClose");
}

- (void)rewardedVideoAdDidClose:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdDidClose");
}

- (void)rewardedVideoAdReward:(MATRewardedVideoAd *)rewardedVideoAd{
    NSLog(@"rewardedVideoAdReward");
}

#pragma -mark nativeAd delegate

- (void)nativeAdLoadSuccess:(MATNativeAd *)nativeAd {
    for (UIView *view in [self.adView subviews]) {
            [view removeFromSuperview];
    }
    if (nativeAd.isTemplateAd) {
        nativeAd.center = CGPointMake(self.adView.frame.size.width/2, nativeAd.center.y);
        [self.adView addSubview:nativeAd];
    }else {
        self.native = nativeAd;
        [self createNativeTemplate:self.native.nativeElements];
        [self.native registerViewForInteraction:self.nativeAdView iConView:self.iconView CTAView:self.ctaBtn];
    }
}

- (void)nativeAdFailed:(MATNativeAd *)nativeAd withError:(NSError*)error {
    NSLog(@"nativeAdFailed withError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Load native ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
    
}

- (void)nativeAdDisplayed:(MATNativeAd *)nativeAd {
    NSLog(@"nativeAdDisplayed");
}

- (void)nativeAdDisplayFailed:(MATNativeAd *)nativeAd {
    NSLog(@"nativeAdDisplayFailed");
}

- (void)nativeAdClicked:(MATNativeAd *)nativeAd {
    NSLog(@"nativeAdClicked");
}
- (void)nativeAdClosed:(MATNativeAd *)nativeAd {
    NSLog(@"nativeAdClosed");
}


//interact
- (void)interactAdLoadSuccess:(MATInteractAd *)interactAd andAdEntranceView:(UIView *)adView {
    for (UIView *view in [self.adView subviews]) {
            [view removeFromSuperview];
    }
    adView.center = CGPointMake(self.adView.frame.size.width/2, self.adView.frame.size.height/2);
    [self.adView addSubview:adView];
}

- (void)interactAdFailed:(MATInteractAd *)interactAd withError:(NSError*)error{
    NSLog(@"nativeAdFailed withError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Load interact ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
}
- (void)InteractAdEntranceShowed:(MATInteractAd *)interactAd{
    NSLog(@"InteractAdEntranceShowed");
}
- (void)interactAdDisplayed:(MATInteractAd *)interactAd{
    NSLog(@"interactAdDisplayed");
}
- (void)interactAdDisplayFailed:(MATInteractAd *)interactAd withError:(NSError*)error{
    NSLog(@"interactAdDisplayFailed withError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Display interact ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
}
- (void)interactAdClicked:(MATInteractAd *)interactAd{
    NSLog(@"interactAdClicked");
}
- (void)interactAdClosed:(MATInteractAd *)interactAd{
    NSLog(@"interactAdClosed");
}


//native ad form element
#pragma --mark TemplateUI ADShow
- (void)createNativeTemplate:(MATNativeAdElements *) natvieModel {
 
    self.nativeAdView = [[UIView alloc] initWithFrame: CGRectMake(0, 0, 300, 250)];
    int gap = 5;
    int AdViewW = self.nativeAdView.frame.size.width;
    int AdViewH = self.nativeAdView.frame.size.height;
    
    int iConW = 30;
    NSOperationQueue *operationQueue = [[NSOperationQueue alloc] init];
    NSInvocationOperation *op = [[NSInvocationOperation alloc] initWithTarget:self selector:@selector(downloadImage) object:nil];
    [operationQueue addOperation:op];
    self.iconView = [[UIImageView alloc] init];
    self.iconView.frame = CGRectMake(gap, gap, iConW, iConW);
    
    int closeBtnX = self.nativeAdView.frame.size.width - 20;
    int closeBtnY = gap;
    int closeBtnSize = 15;
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    closeBtn.frame = CGRectMake(closeBtnX, closeBtnY, closeBtnSize, closeBtnSize);
    [closeBtn setTitle:@"" forState:UIControlStateNormal];
    NSData* imgDataClose = [[NSData alloc]initWithBase64EncodedString:MAT_CloseImage options:0];
    [closeBtn setImage:[UIImage imageWithData:imgDataClose] forState:UIControlStateNormal];
    closeBtn.layer.cornerRadius = 10.0;
    [closeBtn addTarget:self action:@selector(closeClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.nativeAdView addSubview:closeBtn];
    
    
    int titleH = 15;
    int title_des_X = gap + iConW + gap;
    int title_Des_W = AdViewW - 2*gap - iConW - 2*gap;
    UILabel* title = [[UILabel alloc] initWithFrame:CGRectMake(title_des_X, gap, title_Des_W, titleH)];
    title.text = natvieModel.title;
    title.font = [UIFont boldSystemFontOfSize:16.0];
    
    int desH = 15;
    int desY = 2*gap + titleH;
    UILabel* des = [[UILabel alloc] initWithFrame:CGRectMake(title_des_X, desY, title_Des_W, desH)];
    des.text = natvieModel.describe;
    des.font = [UIFont systemFontOfSize:13.0];
    des.textColor = [UIColor grayColor];
    
    int btnH = 30;
    int btnW = AdViewW - 2*gap;
    int btnX = gap;
    int btnY = AdViewH - btnH;
    self.ctaBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.ctaBtn.frame = CGRectMake(btnX, btnY, btnW, btnH);
    [self.ctaBtn setTitle:natvieModel.ctatext forState:UIControlStateNormal];
    [self.ctaBtn setBackgroundColor:[UIColor blackColor]];
//    self.ctaBtn.enabled = NO;
    
    
    int mediaViewX = 0;
    int mediaViewY = desY + desH + gap;
    int mediaViewH = AdViewH - mediaViewY-gap - btnH;
    natvieModel.mediaView.frame = CGRectMake(mediaViewX, mediaViewY, AdViewW, mediaViewH);
    
    int logoW = 30;
    int logoH = 10;
    int logoX = gap;
    int logoY = mediaViewY + mediaViewH - logoH;
    NSData* imgData = [[NSData alloc]initWithBase64EncodedString:MAT_AdLogo options:0];
    UIImageView* logoView = [[UIImageView alloc]initWithFrame:CGRectMake(logoX, logoY, logoW, logoH)];
    logoView.image = [UIImage imageWithData:imgData];
    
    // 添加控件
    [self.nativeAdView addSubview:self.iconView];
    [self.nativeAdView addSubview:title];
    [self.nativeAdView addSubview:des];
    [self.nativeAdView addSubview:self.ctaBtn];
    [self.nativeAdView addSubview:natvieModel.mediaView];
    [self.nativeAdView addSubview:logoView];
    self.nativeAdView.center = CGPointMake(self.adView.frame.size.width/2, self.nativeAdView.center.y);
    [self.adView addSubview:self.nativeAdView];
}

- (void)downloadImage {
    NSURL *imageURL = [NSURL URLWithString:self.native.nativeElements.iconUrl];
    NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
    UIImage *image = [UIImage imageWithData:imageData];
    [self performSelectorOnMainThread:@selector(addImag:) withObject:image waitUntilDone:YES];
}
 
- (void)addImag:(UIImage*)image {
    self.iconView.image = image;
}

- (void)closeClicked:(UIButton *)btn {
    [self initToCloseAdView];
}

#pragma --mark TemplateUI AdClose

- (void)initToCloseAdView {
    
    if ( nil != self.closingAdView) {
        [self.closingAdView removeFromSuperview];
        [self.nativeAdView addSubview:self.closingAdView];
        return;
    }
    
    int gap = 10;
    int allW = 200;
    int allH = 30;
    self.closingAdView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.nativeAdView.frame.size.width, self.nativeAdView.frame.size.height)];
    self.closingAdView.backgroundColor = [UIColor colorWithRed:192.0/255 green:192.0/255 blue:192.0/255 alpha:1];
    
    
    int backBtnX = gap;
    int backBtnY = gap;
    int backBtnSize = 20;
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(backBtnX, backBtnY, backBtnSize, backBtnSize);
    [backBtn setTitle:@"" forState:UIControlStateNormal];
    NSData* imgDataBack = [[NSData alloc]initWithBase64EncodedString:MAT_BackImage options:0];
    [backBtn setImage:[UIImage imageWithData:imgDataBack] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.closingAdView addSubview:backBtn];
    
    int titleY = gap;
    UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(0, titleY, allW, allH)];
    title.text = @"Ad served by zMaticoo";
    title.font = [UIFont boldSystemFontOfSize:16.0];
    title.textAlignment = NSTextAlignmentCenter;
    [self.closingAdView addSubview:title];
    title.center = CGPointMake(self.closingAdView.frame.size.width/2, title.center.y);
    
    
    int btn1Y = gap + allH + 2*gap;
    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn1.frame = CGRectMake(0, btn1Y, allW, allH);
    [btn1 setTitle:@"Not interested in this ad" forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn1 setBackgroundColor:[UIColor whiteColor]];
    btn1.titleLabel.font = [UIFont systemFontOfSize:12];
    btn1.layer.cornerRadius = 6.0;
    btn1.layer.masksToBounds = YES;
    btn1.layer.borderWidth = 1.0;
    btn1.layer.borderColor = [UIColor colorWithRed:92.0/255 green:92.0/255 blue:92.0/255 alpha:1].CGColor;
    [btn1 addTarget:self action:@selector(btn1Clicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.closingAdView addSubview:btn1];
    btn1.center = CGPointMake(self.closingAdView.frame.size.width/2, btn1.center.y);
    
    int btn2Y = gap + 2*allH + 4*gap;
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2.frame = CGRectMake(0, btn2Y, allW, allH);
    [btn2 setTitle:@"Ad was inappropriate" forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn2 setBackgroundColor:[UIColor whiteColor]];
    btn2.titleLabel.font = [UIFont systemFontOfSize:12];
    btn2.layer.cornerRadius = 6.0;
    btn2.layer.masksToBounds = YES;
    btn2.layer.borderWidth = 1.0;
    btn2.layer.borderColor = [UIColor colorWithRed:92.0/255 green:92.0/255 blue:92.0/255 alpha:1].CGColor;
    [btn2 addTarget:self action:@selector(btn2Clicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.closingAdView addSubview:btn2];
    btn2.center = CGPointMake(self.closingAdView.frame.size.width/2, btn2.center.y);
    
    
    int btn3Y = gap + 3*allH + 6*gap;
    UIButton *btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn3.frame = CGRectMake(0, btn3Y, allW, allH);
    [btn3 setTitle:@"Seen this ad multiple times" forState:UIControlStateNormal];
    [btn3 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn3 setBackgroundColor:[UIColor whiteColor]];
    btn3.titleLabel.font = [UIFont systemFontOfSize:12];
    btn3.layer.cornerRadius = 6.0;
    btn3.layer.masksToBounds = YES;
    btn3.layer.borderWidth = 1.0;
    btn3.layer.borderColor = [UIColor colorWithRed:92.0/255 green:92.0/255 blue:92.0/255 alpha:1].CGColor;
    [btn3 addTarget:self action:@selector(btn3Clicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.closingAdView addSubview:btn3];
    btn3.center = CGPointMake(self.closingAdView.frame.size.width/2, btn3.center.y);
    [self.nativeAdView addSubview:self.closingAdView];
}


- (void)initClosedAdView {
    
    int gap = 10;
    int allW = 200;
    int allH = 30;
    self.closedAdView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.nativeAdView.frame.size.width, self.nativeAdView.frame.size.height)];
    self.closedAdView.backgroundColor = [UIColor colorWithRed:192.0/255 green:192.0/255 blue:192.0/255 alpha:1];
    
    int titleY = gap;
    UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(0, titleY, allW, allH)];
    title.text = @"Ad served by zMaticoo";
    title.font = [UIFont boldSystemFontOfSize:16.0];
    title.textAlignment = NSTextAlignmentCenter;
    [self.closedAdView addSubview:title];
    title.center = CGPointMake(self.closedAdView.frame.size.width/2, title.center.y);
    
    int title1Y = gap + titleY + 7*gap;
    UILabel *title1 = [[UILabel alloc]initWithFrame:CGRectMake(0, title1Y, allW, allH)];
    title1.text = @"Thanks for letting us know.";
    title1.font = [UIFont systemFontOfSize:12.0];
    title1.textColor = [UIColor colorWithRed:92.0/255 green:92.0/255 blue:92.0/255 alpha:1];
    title1.textAlignment = NSTextAlignmentCenter;
    [self.closedAdView addSubview:title1];
    title1.center = CGPointMake(self.closedAdView.frame.size.width/2, title1.center.y);
    
    int title2Y = gap + 2*titleY + 9*gap;
    UILabel *title2 = [[UILabel alloc]initWithFrame:CGRectMake(0, title2Y, allW, allH)];
    title2.text = @"zMaticoo improve ads.";
    title2.font = [UIFont systemFontOfSize:12.0];
    title2.textColor = [UIColor colorWithRed:92.0/255 green:92.0/255 blue:92.0/255 alpha:1];
    title2.textAlignment = NSTextAlignmentCenter;
    [self.closedAdView addSubview:title2];
    title2.center = CGPointMake(self.closedAdView.frame.size.width/2, title2.center.y);
    [self.nativeAdView addSubview:self.closedAdView];
    
}

- (void)backClicked:(UIButton *)btn {
    [self.closingAdView removeFromSuperview];
}

- (void)btn1Clicked:(UIButton *)btn {
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [self removeAdSubViewsAddCloseView];
    [self trackAdsCloseToServer:@"Not interested in this ad"];
    
}

- (void)btn2Clicked:(UIButton *)btn {
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [self removeAdSubViewsAddCloseView];
    [self trackAdsCloseToServer:@"Ad was inappropriate"];
}

- (void)btn3Clicked:(UIButton *)btn {
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [self removeAdSubViewsAddCloseView];
    [self trackAdsCloseToServer:@"Seen this ad multiple times"];
}

- (void)removeAdSubViewsAddCloseView {
    for (UIView *subview in self.nativeAdView.subviews) {
        [subview removeFromSuperview];
    }
    [self initClosedAdView];
}

- (void)trackAdsCloseToServer:(NSString *)reason {
    [self.native nativeAdClosedReportWithReason:nil];
}

- (void)splashAdDidLoad:(nonnull MATSplashAd *)splashAd {
    if (splashAd.isReady){
        if (!splashAd.isVideo){
            self.showSplashBtn.enabled = YES;
            self.notification.text = @"Load splash AD success.";
            [self.adView addSubview:self.notification];
        }else{
            self.showSplashVideoBtn.enabled = YES;
            self.notification.text = @"Load splash video AD success.";
            [self.adView addSubview:self.notification];
        }
    }
}

- (void)splashAd:(nonnull MATSplashAd *)splashAd didFailWithError:(nonnull NSError *)error {
    NSLog(@"splashAd didFailWithError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Load splash ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
}

- (void)splashAd:(nonnull MATSplashAd *)splashAd displayFailWithError:(nonnull NSError *)error {
    NSLog(@"splashAd displayFailWithError, %@", error.description);
    dispatch_main_MATASYNC_safe((^{
        self.notification.text = [NSString stringWithFormat:@"Display splash ad failed.\n\n Reason: %@", error.description];
        [self.adView addSubview:self.notification];
    }))
}

- (void)splashAdDidClick:(nonnull MATSplashAd *)splashAd {
    NSLog(@"splashAdDidClick");
}

- (void)splashAdDidClose:(nonnull MATSplashAd *)splashAd {
    NSLog(@"splashAdDidClose");
}

- (void)splashAdWillClose:(nonnull MATSplashAd *)splashAd {
    NSLog(@"splashAdWillClose");
}

- (void)splashAdWillLogImpression:(nonnull MATSplashAd *)splashAd {
    NSLog(@"splashAdWillLogImpression");
}
@end
