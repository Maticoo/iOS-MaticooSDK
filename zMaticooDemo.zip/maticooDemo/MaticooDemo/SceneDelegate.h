//
//  SceneDelegate.h
//  MaticooDemo
//
//  Created by root on 2023/4/12.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

