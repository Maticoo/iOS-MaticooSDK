//
//  ViewController.swift
//  MaticooSwiftDemo
//
//  Created by root on 2023/5/25.
//

import UIKit
import MaticooSDK

class ViewController: UIViewController,MATBannerAdDelegate, MATInterstitialAdDelegate, MATRewardedVideoAdDelegate, MATNativeAdDelegate, MATInteractAdDelegate, MATSplashAdDelegate {
    

    @IBOutlet weak var bannerBtn: UIButton!
    @IBOutlet weak var nativeBtn: UIButton!
    @IBOutlet weak var nativeVideoBtn: UIButton!
    @IBOutlet weak var interstitialBtn: UIButton!
    @IBOutlet weak var interstitialVideoBtn: UIButton!
    @IBOutlet weak var rewardedVideoBtn: UIButton!
    @IBOutlet weak var interactBtn: UIButton!
    @IBOutlet weak var adView: UIView!
    @IBOutlet weak var showInterstitial: UIButton!
    @IBOutlet weak var showInterstitialVideo: UIButton!
    @IBOutlet weak var showRewardedVideo: UIButton!
    @IBOutlet weak var splashBtn: UIButton!
    @IBOutlet weak var splashShow: UIButton!
    @IBOutlet weak var splashVideoBtn: UIButton!
    @IBOutlet weak var splashVideoShow: UIButton!
    
    var banner : MATBannerAd?
    var native : MATNativeAd?
    var nativeVideo : MATNativeAd?
    var interstitial : MATInterstitialAd?
    var interstitialVideo : MATInterstitialAd?
    var rewardedVideo : MATRewardedVideoAd?
    var interact : MATInteractAd?
    var splash : MATSplashAd?
    var splashVideo : MATSplashAd?
    var notification:UILabel?
 
    override func viewDidLoad() {
        super.viewDidLoad()
        showInterstitial.isEnabled = false
        showInterstitialVideo.isEnabled = false
        showRewardedVideo.isEnabled = false
        splashShow.isEnabled = false
        splashVideoShow.isEnabled = false
        notification = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: adView.frame.width, height: 100))
        notification?.center = CGPoint.init(x: adView.frame.width/2, y: 25)
        notification?.textColor = .orange
        notification?.textAlignment = .center
        notification?.numberOfLines = 5
        
        
        // Do any additional setup after loading the view.
        bannerBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        nativeBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        nativeVideoBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        interstitialBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        interstitialVideoBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        rewardedVideoBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        interactBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        showInterstitial.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        showInterstitialVideo.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        showRewardedVideo.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        splashBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        splashVideoBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        splashShow.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        splashVideoShow.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        
    }
    
    
    //携带参数
    @objc func clickEvent(_ sender: UIButton) {
        for subview in adView.subviews {
            subview.removeFromSuperview()
        }
        let title = sender.titleLabel?.text
        if (title! as NSString).contains("Load") {
            banner = nil
            native = nil
            nativeVideo = nil
            interstitial = nil
            interstitialVideo = nil
            rewardedVideo = nil
            interact = nil
            splash = nil
            splashVideo = nil
            showInterstitial.isEnabled = false
            showInterstitialVideo.isEnabled = false
            showRewardedVideo.isEnabled = false
            splashShow.isEnabled = false
            splashVideoShow.isEnabled = false
        }
        
        switch sender.titleLabel?.text{
        case "Load Banner":
            NSLog("%@", "Load Banner")
            self.banner = MATBannerAd(placementID: "1003200873");
            self.banner?.delegate = self
            self.banner?.load()
            
        case "Load Native":
            NSLog("%@", "Load Native")
            self.native = MATNativeAd(placementID: "1003201105");
            self.native?.delegate = self
            self.native?.setAdTemplateStyle()
            //self.native?.nativeElements
            self.native?.load()
            
        case "Load Native Video":
            NSLog("%@", "Load Native Video")
            self.nativeVideo = MATNativeAd(placementID: "1003201139")
            self.nativeVideo?.delegate = self
            self.nativeVideo?.setAdTemplateStyle() //test for template
            self.nativeVideo?.load()
        case "Load Interstitial":
            NSLog("%@", "Load Interstitial")
            showInterstitial.isEnabled = false
            showInterstitialVideo.isEnabled = false
            self.interstitial = MATInterstitialAd(placementID: "1003200946")
            self.interstitial?.delegate = self
            self.interstitial?.loadAd()
            
        case "Load Interstitial Video":
            showInterstitial.isEnabled = false
            showInterstitialVideo.isEnabled = false
            NSLog("%@", "Load Interstitial Video")
            self.interstitial = MATInterstitialAd(placementID: "1003201013")
            self.interstitial?.delegate = self
            self.interstitial?.loadAd()
           
        case "Load Rewarded Video":
            NSLog("%@", "Load Rewarded Video")
            self.rewardedVideo = MATRewardedVideoAd(placementID: "1003200911")
            self.rewardedVideo?.delegate = self
            self.rewardedVideo?.loadAd()
        case "Load Interact":
            NSLog("%@", "Load Interact")
            self.interact = MATInteractAd(placementID: "1003200915")
            self.interact?.delegate = self
            self.interact?.loadAd()
        case "Show Interstitial":
            NSLog("%@", "Show Interstitial")
                self.interstitial?.showFromRootViewController()
                self.showInterstitial.isEnabled = false
            
           
        case "Show Interstitial Video":
            NSLog("%@", "Show Interstitial Video")
                self.interstitialVideo?.showFromRootViewController()
                self.showInterstitialVideo.isEnabled = false
           
        case "Show Rewarded Video":
            NSLog("%@", "Show Rewarded Video")
            rewardedVideo?.showFromRootViewController()
            showRewardedVideo.isEnabled = false
           
        case "Load Splash":
            NSLog("%@", "Load Spalsh")
            self.splash = MATSplashAd(placementID: "1003201174")
            self.splash?.delegate = self
            self.splash?.loadAd()
            
        case "Load Splash Video":
            NSLog("%@", "Load Spalsh Video")
            self.splashVideo = MATSplashAd(placementID: "1003201272")
            self.splashVideo?.delegate = self
            self.splashVideo?.loadAd()
            
        case "Show Splash":
            NSLog("%@", "Show Splash")
            splash?.showFromRootViewController()
            splashShow.isEnabled = false
           
        case "Show Splash Video":
            NSLog("%@", "Show Splash Video")
            splashVideo?.showFromRootViewController()
            splashVideoShow.isEnabled = false
        case .none:
            NSLog("%@", "none")
        case .some(_):
            NSLog("%@", "some")
        }
    }
    
    //banner delegate
    func bannerAdDidLoad(_ bannerAd: MATBannerAd) {
        executeInMainThread {
            bannerAd.frame = CGRect(x: 0, y: 0, width: 320, height: 50)
            self.adView .addSubview(bannerAd)
        }
        
    }
    
    func bannerAd(_ bannerAd: MATBannerAd, didFailWithError error: Error) {
        NSLog("bannerAd didFailWithError, %@", error.localizedDescription)
        executeInMainThread {
            self.notification?.text = "Load bannerAd failed."
            self.adView.addSubview(self.notification!)
        }
        
        
    }
    
    func bannerAdDidImpression(_ bannerAd: MATBannerAd) {
        NSLog("bannerAdDidImpression")
    }
    
    func bannerAdDidClick(_ bannerAd: MATBannerAd) {
        NSLog("bannerAdDidClick")
    }
    
    //intersitital delegate
    func interstitialAdDidLoad(_ interstitialAd: MATInterstitialAd) {
        executeInMainThread {
            if (interstitialAd.isReady){
                if  !interstitialAd.isVideo{
                    self.interstitial = interstitialAd
                    self.showInterstitial.isEnabled = true
                    self.notification?.text = "Load interstitial success."
                }else {
                    self.interstitialVideo = interstitialAd
                    self.showInterstitialVideo.isEnabled = true
                    self.notification?.text = "Load interstitial video success."
                }
                self.adView.addSubview(self.notification!)
    //            interstitialAd.show(from: self)
            }
        }
        
    }
    
    func interstitialAd(_ interstitialAd: MATInterstitialAd, didFailWithError error: Error) {
        NSLog("interstitialAd didFailWithError, %@", error.localizedDescription)
        executeInMainThread {
            if !interstitialAd.isVideo {
                self.notification?.text = "Load interstitial failed: \(error.localizedDescription)"
            }else {
                self.notification?.text = "Load interstitial video failed: \(error.localizedDescription)"
            }
            self.adView.addSubview(self.notification!)
        }
        
    }
    
    func interstitialAd(_ interstitialAd: MATInterstitialAd, displayFailWithError error: Error) {
        NSLog("interstitialAd displayFailWithError, %@", error.localizedDescription)
        executeInMainThread {
            if !interstitialAd.isVideo {
                self.notification?.text = "Load interstitial display failed: \(error.localizedDescription)"
            }else {
                self.notification?.text = "Load interstitial video  display failed: \(error.localizedDescription)"
            }
            self.adView.addSubview(self.notification!)
        }
    }
    
    func interstitialAdWillLogImpression(_ interstitialAd: MATInterstitialAd) {
        NSLog("interstitialAdWillLogImpression")
    }
    
    func interstitialAdDidClick(_ interstitialAd: MATInterstitialAd) {
        NSLog("interstitialAdDidClick")
    }
    
    func interstitialAdWillClose(_ interstitialAd: MATInterstitialAd) {
        NSLog("interstitialAdWillClose")
    }
    
    func interstitialAdDidClose(_ interstitialAd: MATInterstitialAd) {
        NSLog("interstitialAdDidClose")
    }
    
    //rewarded video delegate
    func rewardedVideoAdDidLoad(_ rewardedVideoAd: MATRewardedVideoAd) {
        executeInMainThread {
            self.rewardedVideo = rewardedVideoAd
            if (rewardedVideoAd.isReady){
                self.showRewardedVideo.isEnabled = true
                self.notification?.text = "Load rewarded video success."
                self.adView.addSubview(self.notification!)
            }
        }
        
    }
    
    func rewardedVideoAd(_ rewardedVideoAd: MATRewardedVideoAd, didFailWithError error: Error) {
        NSLog("rewardedVideoAd didFailWithError, %@", error.localizedDescription)
        
        executeInMainThread {
            self.notification?.text = "Load rewarded video failed: \(error.localizedDescription)"
            self.adView.addSubview(self.notification!)
        }
        
    }
    
    func rewardedVideoAd(_ rewardedVideoAd: MATRewardedVideoAd, displayFailWithError error: Error) {
        executeInMainThread {
            self.notification?.text = "Load rewarded display video failed: \(error.localizedDescription)"
            self.adView.addSubview(self.notification!)
        }
        
        NSLog("rewardedVideoAd displayFailWithError, %@", error.localizedDescription)
    }
    
    func rewardedVideoAdStarted(_ rewardedVideoAd: MATRewardedVideoAd) {
        NSLog("rewardedVideoAdStarted")
    }
    
    func rewardedVideoAdCompleted(_ rewardedVideoAd: MATRewardedVideoAd) {
        NSLog("rewardedVideoAdCompleted")
    }
    
    func rewardedVideoAdWillLogImpression(_ rewardedVideoAd: MATRewardedVideoAd) {
        NSLog("rewardedVideoAdWillLogImpression")
    }
    
    func rewardedVideoAdDidClick(_ rewardedVideoAd: MATRewardedVideoAd) {
        NSLog("rewardedVideoAdDidClick")
    }
    
    func rewardedVideoAdWillClose(_ rewardedVideoAd: MATRewardedVideoAd) {
        NSLog("rewardedVideoAdWillClose")
    }
    
    func rewardedVideoAdDidClose(_ rewardedVideoAd: MATRewardedVideoAd) {
        NSLog("rewardedVideoAdDidClose")
    }
    
    func rewardedVideoAdReward(_ rewardedVideoAd: MATRewardedVideoAd) {
        NSLog("rewardedVideoAdReward")
    }
    
    //native
    func nativeAdLoadSuccess(_ nativeAd: MATNativeAd) {
        executeInMainThread {
            if (nativeAd.isTemplateAd) {
                nativeAd.center = CGPointMake(self.adView.frame.size.width/2, nativeAd.center.y)
                self.adView .addSubview(nativeAd)
            }
        }
        
    }
    
    func nativeAdFailed(_ nativeAd: MATNativeAd, withError error: Error) {
        if nil != error {
            NSLog("nativeAdFailed withError, %@", error.localizedDescription)
        }
        
        executeInMainThread {
            self.notification?.text = "Load nativeAd failed. \(error.localizedDescription)"
            self.adView.addSubview(self.notification!)
        }
        
      
        
    }
    
    func nativeAdDisplayed(_ nativeAd: MATNativeAd) {
        NSLog("nativeAdDisplayed")
    }
    
    func nativeAdDisplayFailed(_ nativeAd: MATNativeAd) {
        NSLog("nativeAdDisplayFailed")
    }
    
    func nativeAdClicked(_ nativeAd: MATNativeAd) {
        NSLog("nativeAdClicked")
    }
    
    func nativeAdClosed(_ nativeAd: MATNativeAd) {
        NSLog("nativeAdClosed")
    }
    
    //interact
    func interactAdLoadSuccess(_ interactAd: MATInteractAd, andAdEntranceView adView: UIView) {
        executeInMainThread {
            adView.center = CGPointMake(self.adView.frame.size.width/2, self.adView.frame.size.height/2)
            self.adView.addSubview(adView)
        }
        
    }
    
    func interactAdFailed(_ interactAd: MATInteractAd, withError error: Error) {
        NSLog("nativeAdFailed withError, %@", error.localizedDescription)
        executeInMainThread {
            self.notification?.text = "Load interactAd failed."
            self.adView.addSubview(self.notification!)
        }
        
    }
    
    func interactAdEntranceShowed(_ interactAd: MATInteractAd) {
        NSLog("InteractAdEntranceShowed")
    }
    
    func interactAdDisplayed(_ interactAd: MATInteractAd) {
        NSLog("interactAdDisplayed")
    }
    
    func interactAdDisplayFailed(_ interactAd: MATInteractAd, withError error: Error) {
        NSLog("interactAdDisplayFailed withError, %@", error.localizedDescription)
    }
    
    func interactAdClicked(_ interactAd: MATInteractAd) {
        NSLog("interactAdClicked")
    }
    
    func interactAdClosed(_ interactAd: MATInteractAd) {
        NSLog("interactAdClosed")
    }
    
    //MARK  splash delegate
    func splashAdDidLoad(_ splashAd: MATSplashAd) {
        print("splashAdDidLoad")
        executeInMainThread {
            if !splashAd.isVideo {
                self.splash = splashAd
                self.splashShow.isEnabled = true
                self.notification?.text = "Load splash success."
            }else {
                self.splashVideo = splashAd
                self.splashVideoShow.isEnabled = true
                self.notification?.text = "Load splash video success."
            }
            self.adView.addSubview(self.notification!)
        }

    }
    
    func splashAd(_ splashAd: MATSplashAd, didFailWithError error: Error) {
        print("splashAddidFailWithError")
        executeInMainThread {
            self.notification?.text = "Load splashAd failed: \(error.localizedDescription)."
            self.adView.addSubview(self.notification!)
        }
    }
    
    func splashAd(_ splashAd: MATSplashAd, displayFailWithError error: Error) {
        print("splashAddisplayFailWithError")
        executeInMainThread {
            self.notification?.text = "Load splashAd display failed: \(error.localizedDescription)."
            self.adView.addSubview(self.notification!)
        }    }
    
    func splashAdWillLogImpression(_ splashAd: MATSplashAd) {
        print("splashAdWillLogImpression")
    }
    
    func splashAdDidClick(_ splashAd: MATSplashAd) {
        print("splashAdDidClick")
    }
    
    func splashAdWillClose(_ splashAd: MATSplashAd) {
        print("splashAdWillClose")
    }
    
    func splashAdDidClose(_ splashAd: MATSplashAd) {
        print("splashAdDidClose")
    }
    
    
    func executeInMainThread(_ block: @escaping () -> Void) {
        if Thread.isMainThread {
            block()
        } else {
            DispatchQueue.main.async {
                block()
            }
        }
    }
}

